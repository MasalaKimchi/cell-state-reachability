# Cell-State Reachability Oracle — Manuscript Source

Preprint manuscript + standalone Limitations & Reinforcement Plan for the
convex-cone cell-state reachability oracle (Built with Claude, Life Sciences).

## Build
Requires a TeX distribution with pdflatex + bibtex (natbib, authblk, subcaption,
booktabs, tabularx, placeins). On this project a TinyTeX bundle was used.

```
pdflatex main && bibtex main && pdflatex main && pdflatex main
pdflatex limitations_and_reinforcement_plan   # (x2)
```

## Layout
- `main.tex`                — preprint driver (preamble + \input of sections/)
- `sections/`               — 00_abstract, 10_introduction, 20_methods,
                              30_results, 40_related_work, 50_discussion, 90_supplement
- `references.bib`          — 101 verified BibTeX entries (101/102 works verified via
                              live connectors: 100 OpenAlex-by-DOI + 1 PubMed; 0 fabricated)
- `figures/`                — fig1-5 (main) + figS1-4 (supp), each as 300 dpi PNG + vector PDF
- `manuscript_facts.json`   — locked single-source-of-truth facts sheet (every number in the
                              text is verbatim from here)
- `limitations_and_reinforcement_plan.tex` — standalone self-critique (also embedded as the
                              paper's Discussion)
- `editorial_verdict.json`  — paper-narrative handling-editor arc assessment
- `verification_log.csv`    — per-citation verification record (in the citations artifacts)

## Provenance
Data: Zhu et al. 2025 (CD4+ T-cell CRISPRi Perturb-seq, CZI VCP) and Norman et al. 2019
(K562 CRISPRa, GSE133344). Method: reachability.py (convex-cone NNLS + Farkas/KKT certificate).
